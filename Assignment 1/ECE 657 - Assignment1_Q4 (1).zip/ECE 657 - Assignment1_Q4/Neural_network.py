#!/usr/bin/env python
# coding: utf-8

# # ECE 657 Assignment 1 : Problem 4

# In[2]:


# Importing the libraries
import pandas as pd
import numpy as np
import random
import math
import pickle
import matplotlib.pyplot as plt


# In[3]:


class Neural_Net:
    
# We initialize the list of weights matrices, then store the network architecture and learning rate.
# The "__init__" functions acts as a constructor to Neural_Net class and we are initializing the layer parameters using it.
# We pass the parameter self and later will set the number of nodes to 20 in the hidden layer.

    def __init__(self, hidden_layer):
        self.hidden_layer = hidden_layer
        self.parameters = {}
        self.n = 0
        self.train_cost = []
        self.train_acc = []
        self.val_acc = []

    # compute and return the sigmoid activation value for X
    def sigmoid_ftn(self, X):
        return 1 / (1 + np.exp(-X))
    
    # compute the derivative of the sigmoid function 
    # for this function we are considering that sigmoid_ftn has been called with X
    def sigmoid_der(self, X):
        s = self.sigmoid_ftn(X)
        return s * (1 - s)

    # compute and return the softmax activation value for a given input value
    def softmax_act(self, X):
        expZ = np.exp(X - np.max(X))
        return expZ / expZ.sum(axis=0, keepdims=True)

    def initialize_parameters(self):
        np.random.seed(1)
        # We are creating a weight matrix by randomly linking the number of 
        # nodes in each layer and adding an additional node for the bias.
        self.parameters["Wt1"] = np.random.randn(self.hidden_layer, 784) / np.sqrt(784)
        self.parameters["bias1"] = np.zeros((self.hidden_layer, 1))
        self.parameters["Wt2"] = np.random.randn(4, self.hidden_layer) / np.sqrt(self.hidden_layer)
        self.parameters["bias2"] = np.zeros((4, 1))

            
    # FEEDFORWARD:
    
    # This function takes data in terms of batch and input units and return output values.
    # The fwd_propagation() function computes the output value for the supplied input observation in this case.
    
    def fwd_propagation(self, X):
        store = {}

        # While our data point travels through the network, we compile a list of output activations for each layer
        inp_t = X.T
        
        # Linear transformation between IP and HIDDEN LAYER
        Wt1_hl = self.parameters["Wt1"].dot(inp_t) + self.parameters["bias1"]
        # Applying sigmoid
        act_hl = self.sigmoid_ftn(Wt1_hl)
        # Linear transformation between HIDDEN LAYER and previous layer
        Wt2_op = self.parameters["Wt2"].dot(act_hl) + self.parameters["bias2"]
        # Softmax is the activation function for last layer
        act_op = self.softmax_act(Wt2_op)

        # Storing the values for use later on in back propagation
        store["act_hl"] = act_hl
        store["act_op"] = act_op
        store["Wt1_hl"] = Wt1_hl
        store["Wt2_op"] = Wt2_op
        store["Wt1"] = self.parameters["Wt1"]
        store["Wt2"] = self.parameters["Wt2"]
        store["bias1"] = self.parameters["bias1"]
        store["bias2"] = self.parameters["bias2"]
        return act_op, store

    def back_propagation(self, X, Y, store):
        derivatives = {}
        store["A0"] = X.T
        act_op = store["act_op"]
        # Since we had already used softmax in the last layer, we get probabilistic output from the network. 
        #This will have an exponent component. We choose Cross Entropy as our loss function because the log term in
        #cross entropy and the nature of derivative of softmax function, during back propagation calculation, 
        #we can directly put dL\dY as A - Y. Hence, as per the derivation, we tried to directly calculate the same in our code.
        dY = act_op - Y.T
        dWeight = dY.dot(store["act_hl"].T)/ self.n
        loss_db = np.sum(dY, axis=1, keepdims=True)/ self.n
        #backward function will compute and return the delta
        delta = store["Wt2"].T.dot(dY)
        derivatives["dW2"] = dWeight
        derivatives["db2"] = loss_db
        #Applying chain rule to previous layers, we get the following equations for calculation of derivatives
        dY = delta * self.sigmoid_der(store["Wt1_hl"])
        dWeight = (1. / self.n) * dY.dot(store["A0"].T)
        loss_db = (1. / self.n) * np.sum(dY, axis=1, keepdims=True)
        #Storing the derivatives here
        derivatives["dW1"] = dWeight
        derivatives["db1"] = loss_db
        return derivatives
    
    # Function for training our data
    def train(self, X, Y, X_val, Y_val, learning_rate=0.05, n_iterations=100):
        np.random.seed(22)
        self.n = X.shape[0]
        self.initialize_parameters()
        # creating a for loop for interation for 100 times
        for loop in range(n_iterations):
            #Forward propagation
            inp_t, store = self.fwd_propagation(X)
            #Cross entropy loss function
            cost = -np.mean(Y * np.log(inp_t.T))
            #Backward propagation
            derivatives = self.back_propagation(X, Y, store)
            # Using the derivatives from backprop, we are updating the weights. Here is where the gradient descent happens. 
            # We take a small step
            # as defined by the learning rate towards the direction of the negative of the gradient.
            self.parameters["Wt1"] = self.parameters["Wt1"] - learning_rate * derivatives["dW1"]
            self.parameters["bias1"] = self.parameters["bias1"] - learning_rate * derivatives["db1"]
            self.parameters["Wt2"] = self.parameters["Wt2"] - learning_rate * derivatives["dW2"]
            self.parameters["bias2"] = self.parameters["bias2"] - learning_rate * derivatives["db2"]

            # Printing during training
            if loop % 5 == 0:
                print("Cost: ", cost, "Train Accuracy:", self.pred_acc(X, Y))
            # Saving values for printing
            if loop % 5 == 0:
                self.train_cost.append(cost)
                self.train_acc.append(self.pred_acc(X, Y))
                self.val_acc.append(self.pred_acc(X_val, Y_val))

    # Predicting accuracy to be used in recording training accuracy and validation accuracy
    def pred_acc(self, X, Y):
        A, cache = self.fwd_propagation(X)
        y_hat = np.argmax(A, axis=0)
        Y = np.argmax(Y, axis=1)
        accuracy = (y_hat == Y).mean()
        return accuracy * 100

    
    # Predicts the label of the given input data
    def predict(self,X):
        y_hat,_ = self.fwd_propagation(X)
        y_hat = y_hat.T
        y_hat = (y_hat/np.reshape(np.max(y_hat,axis=1),(-1,1))).astype(int)
        return y_hat

    #Saves the weights for later use
    def save(self):
        for name,value in zip(list(self.parameters.keys()),list(self.parameters.values())):
            np.save(name,value)

    #Loads saved weights
    def load(self):
        for name in ['Wt1','Wt2','bias1','bias2']:
            try:
                self.parameters[name] = np.load(name+".npy")
            except:
                raise(name+".npy file not found...")


# In[ ]:





# In[ ]:




