#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np
from Neural_network import *


# In[5]:


STUDENT_NAME = ["Poojitha Baskaran","Aswathy Baladhandapani","Sapna Pandey"]
STUDENT_ID = ["20906216","20937691", "20939449"]


# In[6]:


def test_mlp(data_file):
    # Load the test set
    X = pd.read_csv(data_file,header=None)
    X = X.to_numpy()
    # Load your network
    # one input layer
    features = 784
    # one hidden layer
    hidden_nodes = 20
    # one output layer
    classes = 4
    # define our multi-layer perceptron
    NN = Neural_network(hidden_nodes)
    # Load weights
    try:
        NN.load()
    except:
        raise("Weights file not found/invalid")

    # Predict test set - one-hot encoded
    y_pred = NN.predict(X)

    return y_pred


'''
How we will test your code:

from test_mlp import test_mlp, STUDENT_NAME, STUDENT_ID
from acc_calc import accuracy 

y_pred = test_mlp('./test_data.csv')

test_labels = ...

test_accuracy = accuracy(test_labels, y_pred)*100
'''


# In[ ]:





# In[ ]:





# In[ ]:




